package com.example.nahasean.dodger;
/*
*This is my first game in android or any sort of programming. As such you will find endless mistakes in the algorithms and implementations of various components.
*Feel free to correct me and make suggestions that will help me learn to be a game developer. This game was made as the 1st of a series of projects I decided to undertake
* to help me learn programming.
*Some of the things I failed to include are:
* 1.Sound effects and background music
* 2.Good management of scores and lives
* 3.A splash screen, play/pause buttons, replay when the game is over
* 4.Levels
* 5.Accurate appearance and disappearance of various sprites without overlapping, and accurate collisions
* 6.Progressive increase in speeds of the baddie and cherry as the player plays
* 7.Progressive increase in number of baddies and of different sizes as the player plays
* 8. etc
*
* IF you manage to implement any of the above omissions, I will be glad to know how you did it.
*
* Author: Nahashon Njenga
* Date: June 13 2016
*Email:nahasean94@hotmail.com,nahaseannjenga@gmail.com
* Studies:Moi University,Kenya
* Program:BSc. Informatics,3 year.
*
*
 */
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.Random;

public class MyDodger extends Activity {
    //create canvas to help us draw
    Canvas canvas;
    MyDodgerView myDodgerView;
    //Sound
//initialize sound variables
//    private SoundPool soundPool;
//    int sample1 = -1;
//    int sample2 = -1;
//    int sample3 = -1;
    //For getting display details like the number of pixels
    Display display;
    //For initializing positions for various sprites
    Point size;
    Point playerPosition,baddiePosition,baddie1Position,baddie2Position,cherryPosition,arrowNextPosition,arrowPrevPosition;
    //screen dimensions
    int screenW;
    int screenH;
    //Game objects
    public Bitmap arrow_next;
    public Bitmap arrow_prev;
    public Bitmap baddie,baddie1,baddie2;
    public Bitmap cherry;
    public Bitmap play_button_down;
    public Bitmap play_button_up;
    public Bitmap player;
    //for objects movement
    boolean baddieIsMovingDown,baddie1IsMovingDown,baddie2IsMovingDown;
    boolean cherryIsMovingDown;
    //for player movement
    boolean playerIsMovingLeft;
    boolean playerIsMovingRight;

//draw the lines
    Paint topLine;
    Paint bottomLine;
    Point topLineStartPosition,topLineEndPosition,bottomLineStartPosition,bottomLineEndPosition;
    //stats
    long lastFrameTime;
    int fps;
    int score=0;
    int lives=40;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myDodgerView=new MyDodgerView(this);
        setContentView(myDodgerView);
        //get the screen size in pixels
        display=getWindowManager().getDefaultDisplay();
        size=new Point();
        display.getSize(size);
        screenW=size.x;
        screenH=size.y;
        //the game objects
        playerPosition=new Point();
        cherryPosition=new Point();
        baddiePosition=new Point();
        baddie1Position=new Point();
        arrowNextPosition=new Point();
        arrowPrevPosition=new Point();
        topLineStartPosition=new Point();
        topLineEndPosition=new Point();
        bottomLineStartPosition=new Point();
        bottomLineEndPosition=new Point();
        baddie2Position=new Point();
        arrow_next= BitmapFactory.decodeResource(getResources(),R.drawable.arrow_next);
        arrow_prev=BitmapFactory.decodeResource(getResources(),R.drawable.arrow_prev);
        baddie=BitmapFactory.decodeResource(getResources(),R.drawable.baddie);
        baddie1=BitmapFactory.decodeResource(getResources(),R.drawable.baddie1);
        baddie2=BitmapFactory.decodeResource(getResources(),R.drawable.baddie2);
        cherry=BitmapFactory.decodeResource(getResources(),R.drawable.cherry);
        player=BitmapFactory.decodeResource(getResources(),R.drawable.player);
        topLine=new Paint();
        bottomLine=new Paint();
        topLine.setAntiAlias(true);
        topLine.setColor(Color.WHITE);
        bottomLine.setAntiAlias(true);
        bottomLine.setColor(Color.WHITE);
        //positioning of the game objects
        topLineStartPosition.x=0;
        topLineStartPosition.y=50;
        topLineEndPosition.x=screenW;
        topLineEndPosition.y=50;
        bottomLineStartPosition.x=0;
        bottomLineStartPosition.y=screenH-90;
        bottomLineEndPosition.x=screenW;
        bottomLineEndPosition.y=screenH-90;
        playerPosition.x=screenW/2;
        playerPosition.y=screenH-150;
        cherryPosition.x=screenW/2;
        cherryPosition.y=topLineStartPosition.y+5;
        baddiePosition.x=screenW/2;
        baddiePosition.y=topLineStartPosition.y+5;
        baddie1Position.x=screenW/3;
        baddie1Position.y=topLineStartPosition.y+5;
        baddie2Position.x=screenW/4;
        baddie2Position.y=topLineStartPosition.y+5;
        arrowPrevPosition.x=0;
        arrowPrevPosition.y=screenH-(arrow_prev.getHeight());
        arrowNextPosition.x=screenW-arrow_next.getWidth();
        arrowNextPosition.y=screenH-arrow_next.getHeight();
//sound
        //though this did not seem to work in my case, if you have a better solution that works please let me know
     /*   soundPool=new SoundPool(10, AudioManager.STREAM_MUSIC,0);
        try{
            AssetManager assetManager=getAssets();
            AssetFileDescriptor assetFileDescriptor;
            assetFileDescriptor=assetManager.openFd("../../res/raw/background.ogg");
            sample1=soundPool.load(assetFileDescriptor,0);
            assetFileDescriptor=assetManager.openFd("gameover.wav");
            sample2=soundPool.load(assetFileDescriptor,0);
            assetFileDescriptor=assetManager.openFd("pickup.wav");
            sample3=soundPool.load(assetFileDescriptor,0);

        }catch (IOException e){

        }*/

    }
    //an inner class that contains our game
    class  MyDodgerView extends SurfaceView implements Runnable{
        //attributes
        Thread ourThread=null;
        SurfaceHolder ourHolder;
        volatile boolean playingDodger=true;
        Paint paint;
//constructor
        public MyDodgerView(Context context) {
            super(context);
            ourHolder=getHolder();
            paint=new Paint();
            baddieIsMovingDown=true;
            baddie1IsMovingDown=true;
            cherryIsMovingDown=true;
        }
        @Override
        public boolean onTouchEvent(MotionEvent motionEvent) {
            //detect user touch events of the screen
            switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {
                case MotionEvent.ACTION_DOWN:
                    //if you touch the previsous button, you move the player right,otherwise left
                    if (motionEvent.getX() >= arrowNextPosition.x && motionEvent.getY() >= arrowNextPosition.y) {
                        playerPosition.x += 10;
                    } else if (motionEvent.getX() >= arrowPrevPosition.x && motionEvent.getY() >= arrowPrevPosition.y && motionEvent.getX() <= (arrow_prev.getWidth() * 2)) {
                        playerPosition.x -= 10;
                    }

                case MotionEvent.ACTION_MOVE:
                    if (motionEvent.getX() >= arrowNextPosition.x && motionEvent.getY() >= arrowNextPosition.y) {
                        playerPosition.x += 10;
                    } else if (motionEvent.getX() >= arrowPrevPosition.x && motionEvent.getY() >= arrowPrevPosition.y && motionEvent.getX() <= (arrow_prev.getWidth() * 2)) {
                        playerPosition.x -= 10;
                    }
            }
            return true;
        }

        @Override
        public void run() {
            while (playingDodger){
                //calls the three methods that control the game
                drawSprites();
                updateSprites();
                controlFPS();
            }

        }

        public void drawSprites(){
            if(ourHolder.getSurface().isValid()){
                canvas=ourHolder.lockCanvas();
                canvas.drawColor(Color.BLACK);//background
                Paint paint=new Paint();
                paint.setColor(Color.argb(255, 255, 255, 255));//white with not trasparency
                paint.setTextSize(25);//text size
                canvas.drawText("Score= "+score,10,40,paint);//write the score
                canvas.drawText("Lives= "+lives,screenW-150,40,paint);//write the lives
                // soundPool.play(sample2,1,1,0,0,1);
//draw the lines
                canvas.drawLine(topLineStartPosition.x,topLineStartPosition.y,topLineEndPosition.x,topLineEndPosition.y,topLine);
                canvas.drawLine(bottomLineStartPosition.x,bottomLineStartPosition.y,bottomLineEndPosition.x,bottomLineEndPosition.y,bottomLine);
                //draw sprites
                canvas.drawBitmap(player,playerPosition.x,playerPosition.y,null);
                canvas.drawBitmap(arrow_next,arrowNextPosition.x,arrowNextPosition.y,null);
                canvas.drawBitmap(arrow_prev,arrowPrevPosition.x,arrowPrevPosition.y,null);
                canvas.drawBitmap(baddie,baddiePosition.x,baddiePosition.y,null);
                canvas.drawBitmap(baddie1,baddie1Position.x,baddie1Position.y,null);
                canvas.drawBitmap(baddie2,baddiePosition.x,baddiePosition.y,null);
                canvas.drawBitmap(cherry,cherryPosition.x,cherryPosition.y,null);

                ourHolder.unlockCanvasAndPost(canvas);

            }

        }

        private void controlFPS() {
            Thread thread=Thread.currentThread();
            //control the frames per second of moving objects

            long timeThisFrame=(System.currentTimeMillis()-lastFrameTime);
            long timeToSleep=15-timeThisFrame;
            if (timeThisFrame>0){
                fps=(int)(1000/timeThisFrame);
            }
            if(timeToSleep>0){
                try{
                    thread.sleep(timeToSleep);
                }
                catch (InterruptedException e){

                }
            }
            lastFrameTime=System.currentTimeMillis();
        }
        //this method did not display the text..probably because of poor positioning...play with the measurements and see what works..let me know :)
        public void gameOver(){
            canvas.drawText("Game Over (:",screenW/2,screenH-40,paint);
           playingDodger=false;

        }
        //pauses the game
        public void pause(){
            Thread thread=Thread.currentThread();
            playingDodger=false;
            try{
                thread.join();
            }catch (InterruptedException e){

            }
        }
        //resumes the game
        public void resume(){
            playingDodger=true;
            ourThread=new Thread(this);
            ourThread.start();
        }

        private void updateSprites() {
            //soundPool.play(sample2,1,1,0,0,1);
            if(baddieIsMovingDown){

                baddiePosition.y=baddiePosition.y+5;//move baddie dowwn
            }
            if(baddie1IsMovingDown){

                baddie1Position.y=baddie1Position.y+6;//move baddie 1 down
            }
            if(baddie2IsMovingDown){

                baddie2Position.y=baddie2Position.y+7;//move baddie 2 down,faster that baddie and baddie1
            }
            if (cherryIsMovingDown) {

                cherryPosition.y=cherryPosition.y+4;//move cherry down
            }
            if(playerIsMovingLeft){
                playerPosition.x=playerPosition.x-10;//move the player left

            }
            if(playerIsMovingRight){
                playerPosition.x=playerPosition.x+10;//move the player right

            }
            //detect collisions
            //hit right of the screen
            if((playerPosition.x+player.getWidth())>screenW){
                playerPosition.x=screenW-(player.getWidth());
                playerIsMovingRight=false;
            }

            //hit the left of the screen
            if(playerPosition.x<0){
                playerPosition.x=0;
                playerIsMovingLeft=false;
            }
            //baddie has hit the bottom of the screen
            if(baddiePosition.y>screenH){
                score++;

                baddieIsMovingDown=false;
                //take him back to the top of the screen
                Random random=new Random();
                baddiePosition.y=topLineStartPosition.y+5+baddie.getHeight();
                int startX=random.nextInt(screenW-baddie.getWidth())+1;
                baddiePosition.x=startX+baddie.getWidth();
                baddieIsMovingDown=true;
            }
            if(baddie1Position.y>screenH){
                score++;
                baddie1IsMovingDown=false;
                //take him back to the top of the screen
                Random random=new Random();
                baddie1Position.y=topLineStartPosition.y+5+baddie1.getHeight();
                int startX=random.nextInt(screenW-baddie1.getWidth())+1;
                baddie1Position.x=startX+baddie1.getWidth();
                baddie1IsMovingDown=true;
            }
            if(baddie2Position.y>screenH){
                score++;
                baddie2IsMovingDown=false;
                //take him back to the top of the screen
                Random random=new Random();
                baddie2Position.y=topLineStartPosition.y+5+baddie2.getHeight();
                int startX=random.nextInt(screenW-baddie2.getWidth())+1;
                baddie2Position.x=startX+baddie2.getWidth();
                baddie2IsMovingDown=true;
            }
            if(cherryPosition.y>=(screenH-10)){
                cherryIsMovingDown=false;
                //take him back to the top of the screen
                Random random=new Random();
                cherryPosition.y=topLineStartPosition.y+5+cherry.getHeight();
                int startX=random.nextInt(screenW-cherry.getWidth())+1;
                cherryPosition.x=startX+cherry.getWidth();
                cherryIsMovingDown=true;
            }
            //detect collision of the chery and baddie with player
            if(baddiePosition.y+baddie.getHeight()>=(playerPosition.y-player.getHeight()/2)){
                lives--;
                Random random=new Random();
                baddiePosition.y=topLineStartPosition.y+5+baddie.getHeight();
                int startX=random.nextInt(screenW-baddie.getWidth());
                baddiePosition.x=(startX+baddie.getWidth())-5;
                baddieIsMovingDown=true;
            }
            if(baddie1Position.y+baddie1.getHeight()>=(playerPosition.y-player.getHeight()/2)){
                lives--;
                Random random=new Random();
                baddie1Position.y=topLineStartPosition.y+5+baddie1.getHeight();
                int startX=random.nextInt(screenW-baddie1.getWidth());
                baddie1Position.x=(startX+baddie1.getWidth())-5;
                baddie1IsMovingDown=true;
            }
            if(baddie2Position.y+baddie2.getHeight()>=(playerPosition.y-player.getHeight()/2)){
                lives--;
                Random random=new Random();
                baddie2Position.y=topLineStartPosition.y+5+baddie2.getHeight();
                int startX=random.nextInt(screenW-baddie2.getWidth());
                baddie2Position.x=(startX+baddie2.getWidth())-5;
                baddie2IsMovingDown=true;
            }
            if(cherryPosition.y+cherry.getHeight()>=(playerPosition.y-player.getHeight()/2)){
                //add more lives and score
                lives++;
                score+=5;
                Random random=new Random();
                cherryPosition.y=1+cherry.getHeight();
                int startX=random.nextInt(screenW-cherry.getWidth());
                cherryPosition.x=(startX+cherry.getWidth())-5;
                cherryIsMovingDown=true;
            }
            if(lives<=0){
                gameOver();
            }

        }
    }
    //the following methods are to deal with some situations that may happen when the user is playing..feel free to add others for most of the things that take place
    //when you are interacting with your phone...
@Override
    public void onStop(){
    super.onStop();
    while (true){
        myDodgerView.pause();
        break;
    }
    finish();
}
    @Override
    protected void onPause() {
        super.onPause();
        myDodgerView.pause();
    }
    @Override
    protected void onResume() {
        super.onResume();
        myDodgerView.resume();
    }

}
//game done

















